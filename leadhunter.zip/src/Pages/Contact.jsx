import React from 'react'
import ContactHero from '../Components/Contact/ContactHero'

function Contact() {
  return (
    <div>
      <ContactHero />
    </div>
  )
}

export default Contact