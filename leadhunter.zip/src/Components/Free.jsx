import React from 'react'

function Free() {
  return (
    <div>
        <div className='py-10'></div>
    </div>
  )
}

export default Free